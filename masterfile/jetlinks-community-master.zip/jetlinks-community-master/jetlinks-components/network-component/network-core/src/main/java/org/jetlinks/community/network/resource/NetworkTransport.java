package org.jetlinks.community.network.resource;

public enum NetworkTransport {
    TCP,
    UDP
}
