package org.jetlinks.community.configure.cluster;

public class Cluster {

    static String ID = "default";


    public static String id() {
        return ID;
    }
}
