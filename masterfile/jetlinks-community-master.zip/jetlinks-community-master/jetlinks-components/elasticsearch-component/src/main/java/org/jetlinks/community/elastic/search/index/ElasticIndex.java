package org.jetlinks.community.elastic.search.index;

/**
 * @version 1.0
 **/
public interface ElasticIndex {

    String getIndex();
}
