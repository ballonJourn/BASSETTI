package org.jetlinks.community.gateway.monitor;

public interface MonitorSupportDeviceGateway {

    long totalConnection();

}
