package org.jetlinks.community.gateway.monitor;

class NoneDeviceGatewayMonitor implements DeviceGatewayMonitor {

    @Override
    public void totalConnection(long total) {

    }

    @Override
    public void connected() {

    }

    @Override
    public void disconnected() {

    }

    @Override
    public void rejected() {

    }

    @Override
    public void receivedMessage() {

    }

    @Override
    public void sentMessage() {

    }
}
