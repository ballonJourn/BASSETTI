package org.jetlinks.community.dashboard;

public interface DashboardDefinition extends Definition {

}