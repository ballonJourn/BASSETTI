package org.jetlinks.community.dashboard;

public interface Definition {
    String getId();

    String getName();



}
